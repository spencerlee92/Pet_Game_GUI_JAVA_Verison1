/*
 * This is junit testing file. Here we run our tests for our pet game.
 */
import Master.*;
import Pet_controller.Pet;
import Pet_controller.Puppy;
import Pet_model.Database;
import java.sql.SQLException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * @author Tao Li
 * @author Bailee Devey
 */
public class PetTests {

    private Pet pet;
    private Master master;
    private Database db;

    public PetTests() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        pet = new Pet();
        master = new Master();
        db = new Database();
    }

    @After
    public void tearDown() {
    }

    /**
     * This test tests whether setting a pet type works correctly.
     */
    @Test
    public void type() {
        pet.setType(new Puppy());
        assertTrue(pet.getType() instanceof Puppy);
    }

    /**
     * This test tests whether the database is empty.
     * @throws SQLException 
     */
    @Test
    public void emptyDB() throws SQLException {
        db.setConnection();
        assertTrue(pet.isDatabaseEmpty());
    }
}
