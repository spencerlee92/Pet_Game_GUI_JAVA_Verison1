/**
 * This is the status panel. This panel loads when the user wants to view the
 * status of their pet, after each activity.
 */
package Pet_view;

import Master.*;
import Pet_view.*;
import Pet_model.*;
import Pet_controller.*;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javafx.scene.paint.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Tao Li
 * @author Bailee Devey
 */
public class StatusPanel extends BasePanel {

    private JButton backButton;
    private JButton seeButton;

    public static JLabel statusLabel;

    private JTextArea wholeStaText;

    private String str;

    public static final int TEXTAREA_ROWS = 8;
    public static final int TEXTAREA_COLUMNS = 10;

    /**
     * Instantiates a new status panel
     *
     * @param img the image source
     */
    public StatusPanel(String img) {
        super(img);
        setLayout(null);

        backButton = new JButton("Back");
        seeButton = new JButton("See");
        wholeStaText = new JTextArea(TEXTAREA_ROWS, TEXTAREA_COLUMNS);

        statusLabel = new JLabel("Below is your pets status:(Please press see button)");

        statusLabel.setFont(new Font("Segoe Print", Font.BOLD, 14));
        wholeStaText.setFont(new Font("Segoe Print", Font.BOLD, 14));

        add(backButton);
        add(statusLabel);
        add(wholeStaText);
        add(seeButton);

        statusLabel.setBounds(WIDTH / 2 - 260, HEIGHT / 2 - 300, 520, 142);
        wholeStaText.setBounds(WIDTH / 2 - 260, HEIGHT / 2 - 200, 520, 200);
        seeButton.setBounds(WIDTH / 2 + 60, HEIGHT / 2 + 180, 120, 42);
        backButton.setBounds(WIDTH / 2 - 220, HEIGHT / 2 + 180, 120, 42);

        backButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                wholeStaText.setText("");

                // System.out.println(Master.player);
                if (Master.player.getType() instanceof Puppy) {
                    PetFrame.cardLayout.show(getParent(), "game");
                } else {
                    PetFrame.cardLayout.show(getParent(), "game2");
                }
            }
        });

        seeButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                wholeStaText.setText("" + Master.player);
            }
        });

    }

}
