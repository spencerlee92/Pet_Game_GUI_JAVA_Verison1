/*
 * This is the continue panel. This panel is applied when the user wants to continue a game.
 */
package Pet_view;

import Pet_controller.Pet;
import Master.*;
import Pet_controller.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

/**
 *
 * @author Tao Li
 * @author Bailee Devey
 */
public class ContinuePanel extends BasePanel {

    /**
     * The saved list.
     */
    private JList<String> saved;

    /**
     * The play button.
     */
    private JButton playButton;

    /**
     * The back button.
     */
    private JButton backButton;

    /**
     * The saved data.
     */
    private String[] saved2;

    /**
     * Instantiates a new load game panel.
     *
     * @param imgSrc the image source
     */
    public ContinuePanel(String imgSrc) {
        super(imgSrc);
        setLayout(null);
        saved2 = Pet.getUserList();

        saved = new JList<>(saved2);
        playButton = new JButton("Play");
        backButton = new JButton("Back");

        saved.setVisibleRowCount(3);
        saved.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        saved.setFixedCellHeight(22);
        saved.setFont(new Font("Comic Sans MS", Font.PLAIN, 16));

        if (saved2.length > saved.getVisibleRowCount()) {
            JScrollPane scrollList = new JScrollPane(saved);
            scrollList.setBorder(null);
            add(scrollList);
            scrollList.setBounds(WIDTH / 2 - 150, HEIGHT / 2, 250, 100);
        } else {
            saved.setBorder(null);
            add(saved);
            saved.setBounds(WIDTH / 2 - 150, HEIGHT / 2, 250, 100);
        }

        add(playButton);
        add(backButton);

        playButton.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 120, 120, 42);
        backButton.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 190, 120, 42);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PetFrame.cardLayout.show(getParent(), "startpanel");
            }
        });

        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (saved.getSelectedValue() != null) {
                    String selectedUsername = saved.getSelectedValue();
                    Pet.setPet2(selectedUsername);
                    //System.out.println(Master.player);
                    if (Master.player.getType() instanceof Puppy) {
                        PetFrame.cardLayout.show(getParent(), "game");
                    } else if (Master.player.getType() instanceof Kitten) {
                        PetFrame.cardLayout.show(getParent(), "game2");
                    } else {
                        System.out.println("*****************Error in ContinuePanel---> playButton actionListener************");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a record from list!", "Information", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                saved2 = Pet.getUserList();
                saved.setListData(saved2);
            }
        });
    }

}
