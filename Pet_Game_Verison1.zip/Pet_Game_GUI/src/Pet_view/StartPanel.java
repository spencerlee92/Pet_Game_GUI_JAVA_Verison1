/**
 * This is the start panel. This panel loads when the user runs the master class.
 * It is the main panel at the start of the game. The user can select to play a new
 * game, continue a previous game, or quit.
 */
package Pet_view;

import Pet_controller.Pet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Tao Li
 * @author Bailee Devey
 */
public class StartPanel extends BasePanel {

    /**
     * The new game button.
     */
    JButton newGameButton;

    /**
     * The load game button.
     */
    JButton continueButton;

    /**
     * The quit button.
     */
    JButton quitButton;

    JLabel label;

    static String font = "Comic Sans MS";

    /**
     * Instantiates a new start panel.
     *
     * @param imgSrc the image source
     */
    public StartPanel(String imgSrc) {
        super(imgSrc);
        setLayout(null);

        JLabel label = new JLabel("Welcome to the pet game!");

        label.setFont(new Font(font, Font.BOLD, 40));
        label.setForeground(Color.RED);
        //add(label, BorderLayout.CENTER);

        newGameButton = new JButton("New Game");
        continueButton = new JButton("Continue");
        quitButton = new JButton("Quit");

        add(label);

        add(newGameButton);
        add(continueButton);
        add(quitButton);

        label.setBounds(WIDTH / 2 - 250, HEIGHT / 2 - 360, 800, 142);
        //words.setBounds(WIDTH/2-60, HEIGHT/2-40, 120, 42);
        newGameButton.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 30, 120, 42);
        continueButton.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 100, 120, 42);
        quitButton.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 170, 120, 42);

        if (Pet.isDatabaseEmpty()) {
            continueButton.setEnabled(false);
        }

        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pet.updateUser();
                JOptionPane.showMessageDialog(null, "Thanks for playing!\nThe users record will be saved.", "Quit", JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
        });

        newGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PetFrame.cardLayout.show(getParent(), "newgame");
            }
        });

        continueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pet.updateUser();
                PetFrame.cardLayout.show(getParent(), "continue");
            }
        });

        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                continueButton.setEnabled(Pet.isDatabaseEmpty() ? false : true);
            }
        });

    }
}
