/*
 * This is the new game panel. This panel loads when the user wants to start a new game.
 */
package Pet_view;

import Pet_controller.Pet;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Pet_model.*;
import Pet_controller.*;
import Master.*;
import java.awt.BorderLayout;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.border.*;
import Master.*;

/**
 *
 * @author Tao Li
 * @author Bailee Devey
 */
public class NewGamePanel extends BasePanel {

    /**
     * The name label.
     */
    private JLabel nameLabel;
    private JLabel ageLabel;
    private JLabel typeLabel;

    /**
     * The name field.
     */
    private JTextField nameField;
    private JTextField ageField;
    private JComboBox<String> typeCombo;

    /**
     * The play button.
     */
    private JButton playButton;

    /**
     * The back button.
     */
    private JButton backButton;

    /**
     * The message box.
     */
    private JDialog msgBox;

    static String font = "Segoe Print";

    /**
     * Instantiates a new new game panel.
     *
     * @param imgSrc the image source
     */
    public NewGamePanel(String imgSrc) {
        super(imgSrc);
        setLayout(null);

        nameLabel = new JLabel("Pet Name", JLabel.CENTER);
        nameField = new JTextField();
        ageLabel = new JLabel("How old do you want your pet to be?", JLabel.CENTER);
        ageField = new JTextField();
        typeLabel = new JLabel("What type of pet do you want?", JLabel.CENTER);
        typeCombo = new JComboBox();

        typeCombo.addItem("Puppy");
        typeCombo.addItem("Kitten");

        playButton = new JButton("Play");
        backButton = new JButton("Back");

        add(nameLabel);
        add(nameField);
        add(ageLabel);
        add(ageField);
        add(typeLabel);
        add(typeCombo);
        add(playButton);
        add(backButton);

        nameLabel.setFont(new Font(font, Font.BOLD, 16));
        nameLabel.setForeground(Color.RED);
        nameLabel.setBounds(WIDTH / 2 - 60, HEIGHT / 2 - 100, 120, 20);

        nameField.setHorizontalAlignment(JTextField.CENTER);
        nameField.setFont(new Font(font, Font.BOLD, 16));
        nameField.setBackground(Color.LIGHT_GRAY);
        nameField.setBorder(null);
        nameField.setBounds(WIDTH / 2 - 100, HEIGHT / 2 - 70, 200, 40);

        ageLabel.setFont(new Font(font, Font.BOLD, 16));
        ageLabel.setForeground(Color.RED);
        ageLabel.setBounds(WIDTH / 2 - 130, HEIGHT / 2 - 20, 320, 20);

        ageField.setHorizontalAlignment(JTextField.CENTER);
        ageField.setFont(new Font(font, Font.BOLD, 16));
        ageField.setBackground(Color.LIGHT_GRAY);
        ageField.setBorder(null);
        ageField.setBounds(WIDTH / 2 - 100, HEIGHT / 2 + 10, 200, 40);

        typeLabel.setFont(new Font(font, Font.BOLD, 16));
        typeLabel.setForeground(Color.RED);
        typeLabel.setBounds(WIDTH / 2 - 130, HEIGHT / 2 + 50, 320, 20);

        typeCombo.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 80, 120, 20);

        playButton.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 110, 120, 42);
        backButton.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 180, 120, 42);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nameField.setText("");
                playButton.setEnabled(true);
                PetFrame.cardLayout.show(getParent(), "startpanel");
            }
        });

        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playButton.setEnabled(false);
                if (nameField.getText().isEmpty()) {
                    nameField.setText("You need to enter a user name!");
                } else if (ageField.getText().isEmpty()) {
                    ageField.setText("Please input age!");
                } else if (!Pet.checkUsername(nameField.getText())) {
                    nameField.setText("Please input characters and numbers only!");
                } else if (!Pet.checkAge(ageField.getText())) {
                    ageField.setText("Please input numbers only!");
                } else if (Pet.hasUser(nameField.getText())) {
                    nameField.setText("User already exists!");
                } else if (Pet.addPet(nameField.getText(), Integer.parseInt(ageField.getText()), (String) typeCombo.getSelectedItem())) {
                    Pet.setPet(nameField.getText(), Integer.parseInt(ageField.getText()), (String) typeCombo.getSelectedItem());
                    // Master.player.setPet(nameField.getText(), Integer.parseInt(ageField.getText()), (String) typeCombo.getSelectedItem());
                    if (((String) typeCombo.getSelectedItem()).equalsIgnoreCase("puppy")) {

                        PetFrame.cardLayout.show(getParent(), "game");
                    } else {
                        PetFrame.cardLayout.show(getParent(), "game2");
                    }
                } else {
                    nameField.setText("Failed creating player!");
                }
            }
        });

        nameField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                nameField.setText("");
                playButton.setEnabled(true);
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });

        ageField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                ageField.setText("");
                playButton.setEnabled(true);
            }

            @Override
            public void focusLost(FocusEvent e) {

            }
        });
    }

}
