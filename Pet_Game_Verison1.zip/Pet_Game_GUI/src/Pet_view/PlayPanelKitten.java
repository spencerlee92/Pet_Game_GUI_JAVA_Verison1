/*
 * This is the kitten play panel. This panel loads when the user creates a 
 * new kitten or loads a previous kitten object. This panel extends the base panel.
 */
package Pet_view;

import Pet_model.*;
import Pet_controller.*;
import Master.*;
import java.awt.BorderLayout;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.border.*;
import Master.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Tao Li
 * @author Bailee Devey
 */
public class PlayPanelKitten extends BasePanel {

    private JButton backButton;
    private JButton confirmButton;
    private JLabel commandLabel;
    public static JComboBox<String> commandBox;

    /**
     * Instantiates a new kitten panel
     *
     * @param img the image source
     */
    public PlayPanelKitten(String img) {
        super(img);
        setLayout(null);

        backButton = new JButton("Back");
        confirmButton = new JButton("Confirm");
        commandLabel = new JLabel("What would you like to do with your puppy?");
        commandBox = new JComboBox();

        commandBox.addItem("Sleep");
        commandBox.addItem("Feed");
        commandBox.addItem("Tricks");
        commandBox.addItem("Play With String");
        commandBox.addItem("Play With Another Kitten");
        commandBox.addItem("Adventure");
        commandBox.addItem("Trampoline");

        add(backButton);
        add(commandLabel);
        add(commandBox);
        add(confirmButton);

        commandLabel.setFont(new Font("", Font.BOLD, 20));
        commandLabel.setForeground(Color.RED);

        commandBox.setBackground(Color.WHITE);

        commandLabel.setBounds(WIDTH / 2 - 200, HEIGHT / 2 - 100, 420, 62);
        commandBox.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 0, 150, 42);
        confirmButton.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 120, 120, 42);
        backButton.setBounds(WIDTH / 2 - 60, HEIGHT / 2 + 180, 120, 42);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pet.updateUser();
                PetFrame.cardLayout.show(getParent(), "startpanel");
            }
        });

        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                System.out.println(Master.player);

                if (commandBox.getSelectedItem() == null) {
                    JOptionPane.showMessageDialog(null, "You need to select a command.", "Quit", JOptionPane.INFORMATION_MESSAGE);
                } else {

                    if (((String) commandBox.getSelectedItem()).equalsIgnoreCase("sleep")) {
                        //StatusPanel.statusLabel = new JLabel(Master.player.sleep(1) + "Your pet is now awake! Below is your pets status:(Please press see button)");
                        JOptionPane.showMessageDialog(null, "" + Master.player.sleep(1), "*******See New Status*******", JOptionPane.INFORMATION_MESSAGE);
                    } else if (((String) commandBox.getSelectedItem()).equalsIgnoreCase("feed")) {
                        JOptionPane.showMessageDialog(null, "" + Master.player.feed(1), "*******See New Status*******", JOptionPane.INFORMATION_MESSAGE);
                    } else if (((String) commandBox.getSelectedItem()).equalsIgnoreCase("adventure")) {
                        try {
                            JOptionPane.showMessageDialog(null, "" + Master.player.adventure(), "*******See New Status*******", JOptionPane.INFORMATION_MESSAGE);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(PlayPanelPuppy.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else if (((String) commandBox.getSelectedItem()).equalsIgnoreCase("tricks")) {
                        JOptionPane.showMessageDialog(null, "" + Master.player.trick(), "*******See New Status*******", JOptionPane.INFORMATION_MESSAGE);
                    } else if (((String) commandBox.getSelectedItem()).equalsIgnoreCase("trampoline")) {
                        try {
                            JOptionPane.showMessageDialog(null, "" + Master.player.trampoline(), "*******See New Status*******", JOptionPane.INFORMATION_MESSAGE);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(PlayPanelPuppy.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else if (((String) commandBox.getSelectedItem()).equalsIgnoreCase("Play With String")) {
                        try {
                            JOptionPane.showMessageDialog(null, "" + Master.player.playWithString(), "*******See New Status*******", JOptionPane.INFORMATION_MESSAGE);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(PlayPanelPuppy.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else if (((String) commandBox.getSelectedItem()).equalsIgnoreCase("Play With Another Kitten")) {
                        try {
                            JOptionPane.showMessageDialog(null, "" + Master.player.playWithAnotherKitten(), "*******See New Status*******", JOptionPane.INFORMATION_MESSAGE);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(PlayPanelPuppy.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    Pet.updateUser();
                    PetFrame.cardLayout.show(getParent(), "status");
                }
            }
        }
        );

    }

}
