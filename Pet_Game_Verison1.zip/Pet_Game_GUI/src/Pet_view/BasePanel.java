/*
 * This is the base panel for the pet game.
 */
package Pet_view;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JComponent;

/**
 *
 * @author Tao Li
 * @author Bailee Devey
 */
public class BasePanel extends JComponent {

    /**
     * The background image.
     */
    private Image image;

    /**
     * The Constant WIDTH.
     */
    public static int WIDTH = 651;

    /**
     * The Constant HEIGHT.
     */
    public static int HEIGHT = 620;

    /**
     * Instantiates a new base panel.
     */
    public BasePanel() {
        image = null;
    }

    /**
     * Instantiates a new base panel.
     *
     * @param imgSrc the image source
     */
    public BasePanel(String imgSrc) {
        image = new ImageIcon(imgSrc).getImage();
    }

    @Override
    public void paintComponent(Graphics g) {
        g.drawImage(image, 0, 0, null);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(WIDTH, HEIGHT);
    }

}
