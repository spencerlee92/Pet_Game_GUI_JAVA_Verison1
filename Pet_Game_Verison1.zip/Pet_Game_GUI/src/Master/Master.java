/*
 * This is the Master Class. From this class, we run our game. The Master class creates a new Pet instance.
 */
package Master;

import Pet_model.Player;
import Pet_view.NewGamePanel;
import Pet_view.PetFrame;
import Pet_view.StartPanel;
import java.awt.EventQueue;
import Pet_controller.*;
import Pet_model.*;
import Pet_view.*;

/**
 *
 * @author Tao Li
 * @author Bailee Devey
 */
public class Master {

    /**
     * These are all the static images which we use as background images in the
     * Graphic game.
     */
    private static final String IMG_SRC = "petbg.png";
    private static final String IMG_SRC2 = "petng.jpg";
    private static final String IMG_SRC3 = "puppy.jpg";
    private static final String IMG_SRC4 = "kitten.png";
    private static final String IMG_SRC5 = "statusbg.jpg";

    public static Player player;

    /**
     * This is the main method for our pet game. This method instantiates a new
     * graphic user interface. It creates all new panels with different static
     * images.
     *
     * @param args
     */
    public static void main(String[] args) {
        player = new Player();

        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                PetFrame gameFrame = new PetFrame();
                StartPanel startPanel = new StartPanel(IMG_SRC);
                NewGamePanel newGamePanel = new NewGamePanel(IMG_SRC2);
                ContinuePanel continuePanel = new ContinuePanel(IMG_SRC2);
                PlayPanelPuppy play_p = new PlayPanelPuppy(IMG_SRC3);
                PlayPanelKitten play_k = new PlayPanelKitten(IMG_SRC4);
                StatusPanel status = new StatusPanel(IMG_SRC5);

                gameFrame.add("startpanel", startPanel);
                gameFrame.add("newgame", newGamePanel);
                gameFrame.add("continue", continuePanel);
                gameFrame.add("game", play_p);
                gameFrame.add("game2", play_k);
                gameFrame.add("status", status);
                gameFrame.setVisible(true);
            }
        });
    }

}
