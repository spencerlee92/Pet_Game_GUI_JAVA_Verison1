/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pet_model;

import Master.Master;
import Pet_controller.*;
import static Pet_controller.Pet.findPet;
import java.text.DecimalFormat;
import java.util.Random;

/**
 *
 * @author Tao Li
 * @author Bailee Devey
 */
public class Player {

    /**
     * The variables.
     */
    private static String username;
    private static int age;
    private static double weight;
    private static int health;
    private static int mood;
    private static int money;
    private static Object type;

    public Player() {
    }

    /**
     * @return the pet name
     */
    public String getUsername() {
        return username;
    }

    /**
     * set pet name
     *
     * @param username the pet name to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the pet age
     */
    public int getAge() {
        return age;
    }

    /**
     * set the pet age
     *
     * @param age the pet age to set
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * @return the pet weight
     */
    public double getWeight() {
        DecimalFormat df = new DecimalFormat("######0.00");
        weight = Double.parseDouble(df.format(weight));
        return weight;
    }

    /**
     * set the pet weight
     *
     * @param weight the pet weight to set
     */
    public void setWeight(double weight) {
        this.weight = weight;
    }

    /**
     * @return the pets health
     */
    public int getHealth() {
        return health;
    }

    /**
     * set the pets health
     *
     * @param health the pets health to set
     */
    public void setHealth(int health) {
        this.health = health;
    }

    /**
     * @return the pets mood
     */
    public int getMood() {
        return mood;
    }

    /**
     * set the pets mood
     *
     * @param mood the pets mood to set
     */
    public void setMood(int mood) {
        this.mood = mood;
    }

    /**
     * @return the pet owners money
     */
    public int getMoney() {
        return money;
    }

    /**
     * set the pet owners money
     *
     * @param money the pet owners money to set
     */
    public void setMoney(int money) {
        this.money = money;
    }

    /**
     * @return the pet type
     */
    public Object getType() {
        return type;
    }

    /**
     * set the pet type
     *
     * @param type the pet type to set
     */
    public void setType(Object type) {
        this.type = type;
    }

    /**
     * The string representation of the pets mood. The pet can be in many moods
     * and this method returns a string representation of their mood
     *
     * @return the string representation of the pet mood.
     */
    public String moodState() {
        String state = "";
        if (this.getMood() >= 75) {
            return state = "really happy";
        } else if (this.getMood() >= 50 && this.getMood() < 75) {
            return state = "fine";
        } else if (this.getMood() >= 25 && this.getMood() < 50) {
            return state = "unhappy";
        } else if (this.getMood() < 25) {
            return state = "depressed";
        }
        return "";
    }

    /**
     * This method returns a string representation of the state of the pet. It
     * includes their name, health status, weight, mood status and the amount of
     * money the user has left.
     *
     * @return string representation of pet state
     */
    public String wholeState() {
        return this.getUsername() + " has " + this.getHealth() + " health, weighs " + this.getWeight() + "kgs and feels " + moodState() + ". You have $" + this.getMoney();
    }

    /**
     * This method returns a string representation of the state of the dead pet.
     * It includes their name, health status, weight and the amount of money the
     * user has left.
     *
     * @return string representation of pet state
     */
    public String deadState() {
        return this.getUsername() + " has " + this.getHealth() + " health, weighs " + this.getWeight() + "kgs. You have $" + this.getMoney();
    }

    /**
     * This is the toString() method which is a string representation of the
     * pet. When the pet object is called to be printed out from the system, the
     * toString() method is what is going to be printed out.
     *
     * @return string representation of the pet
     */
    public String toString() {
        String str = "Your pet details";
        str += "\nName: " + this.getUsername();
        str += "\nAge: " + this.getAge();
        if (this.getType() instanceof Puppy) {
            str += "\nType: Puppy";
        } else if (this.getType() instanceof Kitten) {
            str += "\nType: Kitten";
        }
        str += "\nWeight: " + this.getWeight();
        str += "\nYour initial state is:\n" + wholeState() + "\n";
        return str;
    }

    /**
     * This method is used when the user lets his/her puppy sleep. It will
     * affect the whole status of the pet. The pet will gain (10*hours of sleep)
     * health and 20 mood.
     *
     * @param hours
     * @return string pet is sleeping
     */
    public String sleep(int hours) {
        this.setHealth(this.getHealth() + hours * 10);
        this.setMood(this.getMood() + 20);
        return "Shh...Your pet is sleeping.";
        //Thread.sleep(hours * 1000);
    }

    /**
     * The method is used to let the user feed their pet. It will gain 1.0kg
     * weight. Also it will cost (10*amount) money.
     *
     * @param amount
     * @return string pet just ate some food
     */
    public String feed(int amount) {
        this.setHealth(this.getHealth() + amount);
        this.setWeight(this.getWeight() + 1.0);
        this.setMoney(this.getMoney() - amount * 10);
        //}
        return "You pet just ate some food.";
    }

    /**
     * This method is for adventure. It will randomly generate a path for the
     * pet to go down: Magical forest, haunted house or fairyland. The pet will
     * lose 0.2kgs from going on an adventure. After the pet goes down a certain
     * path, the game will pause for 2 seconds. It will then randomly generate
     * whether the pet finds money or not and will randomly generate the amount
     * of money as well. The pet loses 20 health from the adventure, but if
     * he/she finds money then they will gain 30 mood.
     *
     * @return string representation of the adventure encountered
     * @throws InterruptedException
     */
    public String adventure() throws InterruptedException {
        Random treasure = new Random();
        int newMoney = 0;
        String str = "";
        str += "You find a treasure map.\n";
        str += "You and " + this.getUsername() + " follow the map to try find the treasure.\n";
        Thread.sleep(1000);
        switch (treasure.nextInt(3)) {
            case 1:
                str += "You have entered the magical forest!\n";
                this.setWeight(this.getWeight() - 0.2);
                break;
            case 2:
                str += "You have found a haunted house!\n";
                this.setWeight(this.getWeight() - 0.2);
                break;
            default:
                str += "You have encountered a fairyland!\n";
                this.setWeight(this.getWeight() - 0.2);
                break;
        }
        Thread.sleep(1000);
        if (treasure.nextBoolean()) {
            newMoney = treasure.nextInt(100);
            this.setMoney(this.getMoney() + newMoney);
            this.setMood(this.getMood() + 30);
            this.setHealth(this.getHealth() - 20);
            str += "Lucky find! You found $" + newMoney + " .\n";
        } else {
            str += "Bad Luck. You didn't find anything. Maybe try to go on an adventure next time! \n";
            this.setHealth(this.getHealth() - 20);
        }
        return str;
    }

    /**
     * This method is for a trick. It will randomly generate a trick for the pet
     * to do: Roll over, speak, sit, stand and play dead. The pet will lose
     * 0.1kgs from rolling over. The pet will gain 10 mood from doing a trick.
     *
     * @return string representation of the trick performed
     */
    public String trick() {
        Random trick = new Random();
        String str = "";
        switch (trick.nextInt(5)) {
            case 1:
                str += "Roll over!\n";
                str += this.getUsername() + " is rolling over!\n";
                this.setWeight(this.getWeight() - 0.1);
                break;
            case 2:
                str += "Speak!\n";
                if (type instanceof Puppy) {
                    str += this.getUsername() + " says Woof!\n";
                } else if (type instanceof Kitten) {
                    str += this.getUsername() + " says Meow!\n";
                }
                break;
            case 3:
                str += "Sit!\n";
                str += this.getUsername() + " is sitting!\n";
                break;
            case 4:
                str += "Stand!\n";
                str += this.getUsername() + " is standing!\n";
                break;
            default:
                str += "Play dead!\n";
                str += this.getUsername() + " is playing dead!\n";
                break;
        }
        return str;
    }

    /**
     * This method is for the trampoline. It will sleep for 1 second while the
     * pet jumps on the trampoline. The system will indicate when the pet has
     * completed jumping on the trampoline. The pet will lose 0.1kgs from
     * jumping on the trampoline as well as losing $10 (admission price for
     * going the the trampoline bouncing facility. The pet loses 20 health from
     * jumping on the trampoline but he/she will gain 10 mood.
     *
     * @return string representation of jumping on a tramp.
     * @throws InterruptedException
     */
    public String trampoline() throws InterruptedException {
        String str = "";
        str += "Welcome to the trampoline playland!\n";
        str += this.getUsername() + " is jumping on the trampoline.\n";
        Thread.sleep(1000);
        str += this.getUsername() + " has finished jumping on the trampoline.\n";
        this.setWeight(this.getWeight() - 0.1);
        this.setHealth(this.getHealth() - 20);
        this.setMood(this.getMood() + 10);
        this.setMoney(this.getMoney() - 10);

        return str;
    }

    /**
     * This method is used to let the user play fetch with his/her puppy. When
     * the user throws a ball, the system will pause for 1.5 seconds. Then the
     * screen will print out that the puppy brings the ball back to the user.
     * This action will affect the whole pet status. It will gain 20 mood and 10
     * health, but also lose 0.1kg.
     *
     * @return string representation of playing fetch
     * @throws InterruptedException
     */
    public String playFetch() throws InterruptedException {
        String str = "";
        str += "You threw the ball!\n";
        str += this.getUsername() + " go fetch the ball!\n";
        Thread.sleep(1000);
        str += this.getUsername() + " brings the ball back to you!\n";
        this.setMood(this.getMood() + 20);
        this.setWeight(this.getWeight() - 0.1);
        this.setHealth(this.getHealth() + 10);
        return str;
    }

    /**
     * his method is used to let the user walk his/her puppy. When the user goes
     * for a walk, the system will pause for 3 seconds. Then the screen will
     * indicate the end of walk. This action will affect the whole pet status.
     * It will gain 15 mood and 15 health, but also lose 0.1kg.
     *
     * @return string representation of going for a walk
     * @throws InterruptedException
     */
    public String walk() throws InterruptedException {
        String str = "";
        str += "You take " + this.getUsername() + " for a walk!\n";
        Thread.sleep(1000);
        str += "What a long walk!\n";
        this.setMood(this.getMood() + 15);
        this.setWeight(this.getWeight() - 0.1);
        this.setHealth(this.getHealth() + 15);
        return str;
    }

    /**
     * This method is used to let the user play with his/her kitten. When the
     * user drags the string, the system will pause for 1.5 seconds. Then the
     * screen will print out that the kitten caught the string. This action will
     * affect the whole pet status. It will gain 20 mood and 10 health, but also
     * lose 0.1kg.
     *
     * @return string representation of playing with string
     * @throws InterruptedException
     */
    public String playWithString() throws InterruptedException {
        String str = "";
        str += "You drag the string with the mouse along the ground!\n";
        str += this.getUsername() + " starts to chase it!\n";
        Thread.sleep(1000);
        str += this.getUsername() + " catches it!\n";
        this.setMood(this.getMood() + 20);
        this.setWeight(this.getWeight() - 0.1);
        this.setHealth(this.getHealth() + 10);
        return str;
    }

    /**
     * This method is used to let the kitten try to catch a bird. It uses a
     * Random method to decide if the kitten catch a bird or not. When the user
     * goes for a walk, the system will pause for 1.5 seconds. This action will
     * affect the whole pet status. It will gain 20 mood and 10 health, but also
     * lose 0.1kg.
     *
     * @return string representation of playing with another kitten
     * @throws InterruptedException
     */
    public String playWithAnotherKitten() throws InterruptedException {
        String str = "";
        Random chase = new Random();
        str += this.getUsername() + " is playing with another kitten!\n";
        str += this.getUsername() + " starts to chase a bird!\n";
        Thread.sleep(1000);
        switch (chase.nextInt(2)) {
            case 1:
                str += this.getUsername() + " catches it!\n";
                break;

            default:
                str += "The bird flies away!\n";
                break;
        }
        this.setMood(this.getMood() + 20);
        this.setWeight(this.getWeight() - 0.1);
        this.setHealth(this.getHealth() + 10);
        return str;
    }

}
