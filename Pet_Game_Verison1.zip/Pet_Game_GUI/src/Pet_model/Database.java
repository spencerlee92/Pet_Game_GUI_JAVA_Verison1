/*
 * This class controls the pet database
 */
package Pet_model;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 *
 * @author Tao Li
 * @author Bailee Devey
 */
public class Database {

    /**
     * The connection.
     */
    public static Connection conn;
    public static Statement stat;

    public static String url = "jdbc:derby://localhost:1527/PetDatabase; create = true";

    /**
     * Set the connection.
     *
     * @throws SQLException the SQL exception
     */
    public static void setConnection() throws SQLException {
        conn = DriverManager.getConnection(url, "pet", "pet");
        stat = conn.createStatement();
        checkTableExisting("PET");
        System.out.println("DB setup done!");
    }

    /**
     * Execute update.
     *
     * @param command the SQL command
     * @return the integer representation of the execution status
     * @throws SQLException the SQL exception
     */
    public static int setUpdate(String command) throws SQLException {
        if (conn == null) {
            setConnection();
        }
        Statement stat = conn.createStatement();
        return stat.executeUpdate(command);
    }

    /**
     * Execute query.
     *
     * @param command the SQL command
     * @return the result set
     * @throws SQLException the SQL exception
     */
    public static ResultSet setQuery(String command) throws SQLException {
        if (conn == null) {
            setConnection();
        }
        Statement stat = conn.createStatement();
        return stat.executeQuery(command);
    }

    /**
     * check if a table already exists
     * if the table doesn't already exist then create a new table
     * @param newTableName
     */
    private static void checkTableExisting(String newTableName) {
        try {
            System.out.println("check existing tables.... ");
            String[] types = {"TABLE"};
            DatabaseMetaData dbmd = conn.getMetaData();
            ResultSet rsDBMeta = dbmd.getTables(null, null, null, null);//types);
            Statement dropStatement = null;

            while (rsDBMeta.next()) {
                String tableName = rsDBMeta.getString("TABLE_NAME");
                System.out.println("found: " + tableName);
                if (tableName.compareToIgnoreCase(newTableName) != 0) {
                    stat.executeUpdate("CREATE TABLE PET (NAME VARCHAR(50), AGE INT, WEIGHT DOUBLE, HEALTH INT, MOOD INT, MONEY INT, ANIMAL INT)");
                }

            }
            if (rsDBMeta != null) {
                rsDBMeta.close();
            }
            if (dropStatement != null) {
                dropStatement.close();
            }

        } catch (SQLException ex) {
        }

    }

}
