/*
 * This is the pet class which controls the kitten and puppy activity methods.
 */
package Pet_controller;

import Pet_model.Database;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Pet_model.*;
import Master.*;
import java.text.DecimalFormat;

/**
 *
 * @author Tao Li
 * @author Bailee Devey
 */
public class Pet {

    /**
     * The variables
     */
    private String username;
    private int age;
    private double weight;
    private int health;
    private int mood;
    private int money;
    private Object type;

    /**
     * Default constructor.
     */
    public Pet() {
        username = "";
        age = 0;
        weight = 0.0;
        health = 0;
        mood = 0;
        money = 0;
        type = null;
    }

    /**
     * Instantiates a new pet with a constructor.
     */
    public Pet(String name, int age, double weight, int health, int money, int mood, Object type) {
        this.username = name;
        this.age = age;
        this.weight = weight;
        this.health = health;
        this.money = money;
        this.mood = mood;
        this.type = type;
    }

    /**
     * Check username.
     *
     * @param username the username
     * @return true, if the username is not valid
     */
    public static boolean checkUsername(String username) {
        for (char ch : username.toCharArray()) {
            if (!((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))) {
                System.out.println(ch);
                return false;
            }
        }
        return true;
    }

    /**
     * Check the pet age
     *
     * @param age the pets age
     * @return true if age is invalid.
     */
    public static boolean checkAge(String age) {
        for (char ch : age.toCharArray()) {
            if (!(ch >= '0' && ch <= '9')) {
                System.out.println(ch);
                return false;
            }
        }
        return true;
    }

    /**
     * Checks if database is empty.
     *
     * @return true, if database is empty
     */
    public static boolean isDatabaseEmpty() {
        try {
            ResultSet num = Database.setQuery("SELECT COUNT(*) FROM PET");
            while (num.next()) {
                if (num.getInt(1) == 0) {
                    return true;
                }
            }
        } catch (SQLException e) {
            return true;
        }
        return false;
    }

    /**
     * Checks for user in database.
     *
     * @param username the username
     * @return true, if the user exists in database
     */
    public static boolean hasUser(String username) {
        try {
            ResultSet name = Database.setQuery("SELECT NAME FROM PET");
            while (name.next()) {
                if (name.getString(1).equals(username)) {
                    return true;
                }
            }
        } catch (SQLException e) {
            return true;
        }

        return false;
    }

    /**
     * Gets the user by name from database.
     *
     * @param username the username
     * @return a pet object if the user exists in the database
     */
    public static Pet findPet(String username) {
        String name;
        int age;
        double weight;
        int health;
        int mood;
        int money;
        Object type;
        try {
            String sqlQuery = "SELECT * FROM PET WHERE NAME = '" + username + "'";
            ResultSet rs = Database.setQuery(sqlQuery);
            while (rs.next()) {
                age = rs.getInt("AGE");
                weight = rs.getDouble("WEIGHT");
                health = rs.getInt("HEALTH");
                mood = rs.getInt("MOOD");
                money = rs.getInt("MONEY");
                if (rs.getInt("ANIMAL") == 1) {
                    type = new Puppy();
                } else {
                    type = new Kitten();

                }
                return new Pet(username, age, weight, health, mood, money, type);
            }
        } catch (SQLException e) {
            return null;
        }
        return null;
    }

    /**
     * Gets the user list.
     *
     * @return the user list
     */
    public static String[] getUserList() {
        ArrayList<String> userList = null;
        try {
            userList = new ArrayList<>();
            ResultSet nameSet = Database.setQuery("SELECT NAME FROM PET");
            while (nameSet.next()) {
                userList.add(nameSet.getString("NAME"));
            }
        } catch (Exception e) {
        }
        String[] stringArray = userList.toArray(new String[userList.size()]);
        return stringArray;
    }

    /**
     * Instantiate a new pet with some default values
     *
     * @param username the username
     * @param age pet age
     * @param type pet type
     */
    public static void setPet(String username, int age, String type) {
        Pet pet = findPet(username);
        Master.player.setUsername(username);
        Master.player.setAge(age);
        Master.player.setWeight(1.0);
        Master.player.setHealth(100);
        Master.player.setMood(100);
        Master.player.setMoney(100);
        if (type.equalsIgnoreCase("puppy")) {
            Master.player.setType(new Puppy());
        } else {
            Master.player.setType(new Kitten());
        }
    }

    /**
     * Instantiate a new pet with the data from the database
     *
     * @param username the username
     */
    public static void setPet2(String username) {
        Pet pet = findPet(username);
        Master.player.setUsername(username);
        Master.player.setAge(pet.getAge());
        Master.player.setWeight(pet.getWeight());
        Master.player.setHealth(pet.getHealth());
        Master.player.setMood(pet.getMood());
        Master.player.setMoney(pet.getMoney());

        Master.player.setType(pet.getType());

    }

    /**
     * Add a pet to the database.
     *
     * @param username the username
     * @param age pet age
     * @param type pet type
     * @return true, if successful
     */
    public static boolean addPet(String username, int age, String type) {
        String command;
        if (type.equalsIgnoreCase("puppy")) {
            command = "INSERT INTO PET VALUES ('" + username + "'" + "," + age + "," + 1.0 + "," + 100 + "," + 100 + "," + 100 + ", 1)";
        } else {

            command = "INSERT INTO PET VALUES ('" + username + "'" + "," + age + "," + 1.0 + "," + 100 + "," + 100 + "," + 100 + ", 2)";

        }
        try {
            Database.setUpdate(command);
        } catch (SQLException e) {
            return false;
        }
        return true;
    }

    /**
     * Delete a pet by name.
     *
     * @param username the username
     * @return true, if successful
     */
    public static boolean deleteUserByName(String username) {
        String command = "DELETE FROM PET WHERE NAME = '" + username + "'";
        try {
            Database.setUpdate(command);
        } catch (SQLException e) {
            return false;
        }
        return true;
    }

    /**
     * Update a pet.
     */
    public static void updateUser() {
        String name = Master.player.getUsername();
        int age = Master.player.getAge();
        Double weight = Master.player.getWeight();
        int health = Master.player.getHealth();
        int mood = Master.player.getMood();
        int money = Master.player.getMoney();
        String command = "";

        deleteUserByName(name);

        if (Master.player.getType() instanceof Puppy) {
            command = "INSERT INTO PET VALUES ('" + name + "'" + "," + age + "," + weight + "," + health + "," + mood + "," + money + ", 1)";
        } else if (Master.player.getType() instanceof Kitten) {
            command = "INSERT INTO PET VALUES ('" + name + "'" + "," + age + "," + weight + "," + health + "," + mood + "," + money + ", 2)";
        } else {
            System.out.println("*******************Error at Pet-->UpdateUser()*********************");
        }
        try {
            Database.setUpdate(command);
        } catch (SQLException e) {
        }
    }

    /**
     * @return the pet name
     */
    public String getUsername() {
        return username;
    }

    /**
     * set pet name
     *
     * @param username the pet name to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the pet age
     */
    public int getAge() {
        return age;
    }

    /**
     * set the pet age
     *
     * @param age the pet age to set
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * @return the pet weight
     */
    public double getWeight() {
        DecimalFormat df = new DecimalFormat("######0.00");
        weight = Double.parseDouble(df.format(weight));
        return weight;
    }

    /**
     * set the pet weight
     *
     * @param weight the pet weight to set
     */
    public void setWeight(double weight) {
        this.weight = weight;
    }

    /**
     * @return the pets health
     */
    public int getHealth() {
        return health;
    }

    /**
     * set the pets health
     *
     * @param health the pets health to set
     */
    public void setHealth(int health) {
        this.health = health;
    }

    /**
     * @return the pets mood
     */
    public int getMood() {
        return mood;
    }

    /**
     * set the pets mood
     *
     * @param mood the pets mood to set
     */
    public void setMood(int mood) {
        this.mood = mood;
    }

    /**
     * @return the pet owners money
     */
    public int getMoney() {
        return money;
    }

    /**
     * set the pet owners money
     *
     * @param money the pet owners money to set
     */
    public void setMoney(int money) {
        this.money = money;
    }

    /**
     * @return the pet type
     */
    public Object getType() {
        return type;
    }

    /**
     * set the pet type
     *
     * @param type the pet type to set
     */
    public void setType(Object type) {
        this.type = type;
    }

}
