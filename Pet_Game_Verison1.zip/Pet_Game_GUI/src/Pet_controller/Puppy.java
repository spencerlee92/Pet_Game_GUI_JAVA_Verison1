/*
 * This is a puppy class. It extends the pet class, therefore inheriting all of its methods
 */
package Pet_controller;

/**
 * @author Tao Li
 * @author Bailee Devey
 */
public class Puppy extends Pet {

    /**
     * This is a constructor which inherits the variables in the pet class. It
     * uses the super key word to do that.
     */
    public Puppy() {
        super();
    }

}
